const express = require('express');
const jwt = require('jsonwebtoken');
const { DynamoDBClient, PutItemCommand, ScanCommand } = require('@aws-sdk/client-dynamodb'); // AWS SDK v3 DynamoDB Client
const axios = require('axios');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid'); // To generate UUID for custom entries

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Configura el cliente de DynamoDB (v3)
const dynamoDbClient = new DynamoDBClient({
  region: 'us-east-1', // Usa la región que prefieras
});

// Define las tablas en DynamoDB
const FUSIONADOS_TABLE = 'Fusionados'; // La tabla para almacenar los datos fusionados
const PERSONALIZED_TABLE = 'PersonalizedData'; // Tabla para almacenar la información personalizada

// Configura las URLs de las APIs
const SWAPI_URL = 'https://swapi.dev/api/people/';
const WEATHER_API_URL = 'https://api.openweathermap.org/data/2.5/weather?q=Lima,pe&APPID=7c56665eb13ac1a14b766c036e6743a9';

// Helper function para obtener los personajes de Star Wars
async function getStarWarsCharacters() {
  const response = await axios.get(SWAPI_URL);
  return response.data.results;
}

// Helper function para obtener el clima de un planeta
async function getWeatherData(planetName) {
  const weatherUrl = WEATHER_API_URL.replace('{city}', planetName);
  const response = await axios.get(weatherUrl);
  return {
    temperature: response.data.main.temp,
    humidity: response.data.main.humidity,
    description: response.data.weather[0].description,
  };
}

// Endpoint GET /fusionados
app.get('/fusionados', async (req, res) => {
  try {
    // Obtener personajes de Star Wars
    const characters = await getStarWarsCharacters();

    const fusionados = [];
    for (const character of characters) {
      const weatherData = await getWeatherData(character.homeworld);
      fusionados.push({
        name: character.name,
        gender: character.gender,
        birth_year: character.birth_year,
        homeworld: character.homeworld,
        weather: weatherData,
        timestamp: new Date().toISOString(),
      });
    }

    // Guardar los datos fusionados en DynamoDB
    const promises = fusionados.map((data) => {
      const params = {
        TableName: FUSIONADOS_TABLE,
        Item: {
          ...data,
          timestamp: { S: data.timestamp }, // DynamoDB requires type-mapped objects
        },
      };
      const command = new PutItemCommand(params);
      return dynamoDbClient.send(command);
    });

    await Promise.all(promises);

    res.status(200).json(fusionados);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener datos de las APIs' });
  }
});

// Endpoint POST /almacenar
app.post('/almacenar', async (req, res) => {
  try {
    const { name, description } = req.body;

    // Asegurarse de que la información esté bien formada
    if (!name || !description) {
      return res.status(400).json({ error: 'El nombre y la descripción son obligatorios' });
    }

    const params = {
      TableName: PERSONALIZED_TABLE,
      Item: {
        id: { S: uuidv4() },
        name: { S: name },
        description: { S: description },
        timestamp: { S: new Date().toISOString() },
      },
    };

    const command = new PutItemCommand(params);
    await dynamoDbClient.send(command);
    res.status(201).json({ message: 'Información personalizada almacenada correctamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al almacenar la información personalizada' });
  }
});

// Endpoint GET /historial
app.get('/historial', async (req, res) => {
  try {
    const { limit = 10, page = 1 } = req.query;

    // Definir el rango de paginación
    const params = {
      TableName: FUSIONADOS_TABLE,
      Limit: limit,
      ExclusiveStartKey: page > 1 ? { timestamp: { S: (page - 1) * limit } } : undefined,
    };

    const command = new ScanCommand(params);
    const data = await dynamoDbClient.send(command);

    res.status(200).json({
      items: data.Items ? data.Items.map(AWS.DynamoDB.Converter.unmarshall) : [],
      totalItems: data.Count,
      totalPages: Math.ceil(data.Count / limit),
      currentPage: page,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener el historial' });
  }
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
