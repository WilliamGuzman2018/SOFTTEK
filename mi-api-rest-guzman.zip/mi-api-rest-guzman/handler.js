// handler.js
module.exports.getItems = async (event) => {
    // Aquí se puede realizar una consulta a una base de datos, por ejemplo.
    const items = [
      { id: 1, name: 'Item 1' },
      { id: 2, name: 'Item 2' }
    ];
    return {
      statusCode: 200,
      body: JSON.stringify({ items })
    };
  };
  
  module.exports.createItem = async (event) => {
    const body = JSON.parse(event.body);
    const newItem = { id: 3, name: body.name };
    
    // Aquí puedes insertar el nuevo elemento en una base de datos.
    return {
      statusCode: 201,
      body: JSON.stringify({ message: 'Item creado', item: newItem })
    };
  };
  
  module.exports.updateItem = async (event) => {
    const { id } = event.pathParameters;
    const body = JSON.parse(event.body);
    
    // Aquí puedes actualizar el elemento con el ID dado.
    const updatedItem = { id, name: body.name };
  
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Item actualizado', item: updatedItem })
    };
  };
  
  module.exports.deleteItem = async (event) => {
    const { id } = event.pathParameters;
    
    // Aquí puedes eliminar el elemento con el ID dado.
    return {
      statusCode: 200,
      body: JSON.stringify({ message: `Item con id ${id} deleted` })
    };
  };
  