import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Modelo de los datos meteorológicos
interface Weather {
  temperature: number;
  humidity: number;
  weatherDescription: string;
}

// Modelo de los planetas
interface Planet {
  name: string;
  climate: string;
  terrain: string;
  population: string;
}

// Modelo de los personajes de Star Wars
interface Character {
  name: string;
  gender: string;
  birth_year: string;
  homeworld: string;
 
  weather: Weather | null;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private starWarsApiUrl = 'https://swapi.dev/api/people/';
  private weatherApiUrl = 'https://api.openweathermap.org/data/2.5/weather?q=Lima,pe&APPID=7c56665eb13ac1a14b766c036e6743a9';

  constructor(private http: HttpClient) { }

  // Obtener personajes de Star Wars
  getCharacters(): Observable<any> {
    return this.http.get<any>(this.starWarsApiUrl);
  }

  // Obtener clima de un planeta
  getWeather(planetName: string): Observable<any> {
    const weatherUrl = this.weatherApiUrl.replace('{Lima}', planetName).replace('{7c56665eb13ac1a14b766c036e6743a9}', '7c56665eb13ac1a14b766c036e6743a9');
    return this.http.get<any>(weatherUrl);
  }

  // Obtener datos fusionados (personajes con clima)
  getCharactersWithWeather(): Observable<any> {
    return new Observable(observer => {
      this.getCharacters().subscribe(charactersData => {
        const charactersWithWeather: Character[] = []; // Definir tipo explícito
        let completedRequests = 0;
        
        charactersData.results.forEach((character: Character) => {
          this.getWeather(character.homeworld).subscribe(weatherData => {
            const planetWeather = weatherData ? {
              temperature: weatherData.main.temp,
              humidity: weatherData.main.humidity,
              weatherDescription: weatherData.weather[0].description
            } : null;
            
            charactersWithWeather.push({
              name: character.name,
              gender: character.gender,
              birth_year: character.birth_year,
              homeworld: character.homeworld,
              weather: planetWeather
            });

            completedRequests++;
            // Solo emitimos el resultado cuando todas las solicitudes se completaron
            if (completedRequests === charactersData.results.length) {
              observer.next(charactersWithWeather);
              observer.complete();
            }
          });
        });
      });
    });
  }
}
