import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';  // Importa HttpClientModule

import { AppComponent } from './app.component';
import { ApiService } from './api.service';  // Asegúrate de que ApiService esté bien importado

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule  // Asegúrate de agregar HttpClientModule a imports
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
